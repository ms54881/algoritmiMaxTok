package projektR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjektRApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjektRApplication.class, args);
	}

}
